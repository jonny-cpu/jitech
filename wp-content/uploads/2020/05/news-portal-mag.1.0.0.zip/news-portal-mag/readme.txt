=== News Portal Mag ===

Contributors:       mysterythemes
Requires at least:  WordPress 4.0
Tested up to:       WordPress 5.0
Stable tag: 		1.0.0
Requires PHP: 		5.6
License:            GPLv3 or later
License URI:        http://www.gnu.org/licenses/gpl-3.0.html
Tags:               news, blog, entertainment, grid-layout, one-column, two-columns, three-columns, left-sidebar, right-sidebar, custom-colors, custom-logo, featured-image-header, footer-widgets, full-width-template, rtl-language-support, theme-options, translation-ready


== Description ==

News Portal Mag is child theme of News Portal. This is ultimate magazine theme with creative design and powerful features that allow you to quickly and easily create a style to suit your needs. It is completely built on Customizer which allows you to customize most of the theme settings easily with live previews. It is the fully widgetized theme so as to let users manage the website using the easy to use widgets. News Portal Mag Theme is the best choice to create a Beautiful & Powerful News/magazine/blog websites with ease. Get free support at https://mysterythemes.com/support/forum/themes/child-themes/ and check the demo at http://demo.mysterythemes.com/child-theme/news-portal-mag/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

News Portal is distributed under the terms of the GNU GPL V3.

News Portal Mag WordPress Theme, Copyright 2019 Mystery Themes.
News Portal Mag is distributed under the terms of the GNU GPL

== Resources ==

	Screenshot Images
    Licenses: CCO Public Domain

    https://pxhere.com/en/photo/741704
	https://pxhere.com/en/photo/441999
	https://pxhere.com/en/photo/1172567
	https://pxhere.com/en/photo/1117918
	https://pxhere.com/en/photo/668852
	https://pxhere.com/en/photo/1487467
	https://pxhere.com/en/photo/1209019
	https://pxhere.com/en/photo/715392
	https://pxhere.com/en/photo/136797
	https://pxhere.com/en/photo/15030


== Changelog ==

= 1.0.0 = 25th July
	* Initial release.